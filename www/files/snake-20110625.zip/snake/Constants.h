#ifndef CONSTANTS_H
#define CONSTANTS_H

enum Direction
{
	North, 
	NorthEast,
	East,
	SouthEast,
	South,
	SouthWest,
	West,
	NorthWest
};
#endif

