#include "SnakeListener.h"

SnakeListener::SnakeListener()
{
}

SnakeListener::~SnakeListener()
{
}

